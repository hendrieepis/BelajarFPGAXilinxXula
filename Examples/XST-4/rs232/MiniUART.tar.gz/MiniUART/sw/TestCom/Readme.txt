TestCom is a test program built to test a serial line connected in closed-loop,
or to test an equipement configured in closed-loop.
Developed under Borland C++ Builder 5.
Feel free to use/edit/modify.

Note: CC3250.DLL and VCL50.BPL are available at http://www.chez.com/pcar/download.html