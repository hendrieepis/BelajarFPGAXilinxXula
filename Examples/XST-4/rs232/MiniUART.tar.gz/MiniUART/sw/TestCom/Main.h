void ReceiveCallBack(char *c);
BOOL WINAPI CtrlHandler(DWORD dwCtrlType);
